"""
Numerical simulation for disturbance-induced synchronization of two
wheeled mobile robots coupled to a sinusoidal disturbance distribution
d(t) = d0 + Ad*sin(omega_d*t).

Generates (matching the paper's figure numbering):
  fig2_disturbance.png  - the d(t) sinusoidal distribution
  fig3_convergence.png  - state trajectories under a representative k
  fig4_error_decay.png  - ||e(t)|| for k in {0.1,0.5,2.0}, log scale
  fig5_delay.png        - error under delayed reception of d(t)
"""

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------
# Sinusoidal disturbance distribution
# ---------------------------------------------------------------------
d0, A_d, omega_d = 3.0, 1.5, 0.5

def d(t):
    return d0 + A_d * np.sin(omega_d * t)

d_max = A_d * omega_d  # bound on |d_dot(t)|

def d_delayed(t, tau):
    return d0 + A_d * np.sin(omega_d * (t - tau))

# ---------------------------------------------------------------------
# Coupled robot dynamics
# ---------------------------------------------------------------------
def rhs(t, z, k, v_i, w_i, v_j, w_j, delayed=False, tau_i=0.0, tau_j=0.0):
    xi, yi, thi, xj, yj, thj = z
    if delayed:
        di, dj = d_delayed(t, tau_i), d_delayed(t, tau_j)
    else:
        di = dj = d(t)

    xi_dot = v_i * np.cos(thi) + k * (di - xi)
    yi_dot = v_i * np.sin(thi) + k * (di - yi)
    thi_dot = w_i + k * (di - thi)

    xj_dot = v_j * np.cos(thj) + k * (dj - xj)
    yj_dot = v_j * np.sin(thj) + k * (dj - yj)
    thj_dot = w_j + k * (dj - thj)

    return [xi_dot, yi_dot, thi_dot, xj_dot, yj_dot, thj_dot]

T_final = 40.0
t_eval = np.linspace(0, T_final, 4000)
v_i, w_i = 1.0, 0.15
v_j, w_j = 0.7, -0.10
z0 = [0.0, 0.0, 0.0, 8.0, -6.0, 2.5]
k_values = [0.1, 0.5, 2.0]
colors = {0.1: "tab:red", 0.5: "tab:orange", 2.0: "tab:green"}

results = {}
for k in k_values:
    sol = solve_ivp(rhs, [0, T_final], z0, t_eval=t_eval, args=(k, v_i, w_i, v_j, w_j),
                     method="RK45", rtol=1e-8, atol=1e-10)
    results[k] = sol

# ---- Fig 2: disturbance distribution ----
fig, ax = plt.subplots(figsize=(6, 3.2))
t_plot = np.linspace(0, T_final, 1000)
ax.plot(t_plot, d(t_plot), color="tab:blue", lw=2)
ax.axhline(d0, color="gray", ls="--", lw=1, label=r"mean level $d_0$")
ax.set_xlabel("t (s)"); ax.set_ylabel(r"$d(t)$")
ax.set_title(r"Disturbance distribution $d(t)=d_0+A_d\sin(\omega_d t)$")
ax.legend(fontsize=8); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig("fig2_disturbance.png", dpi=200); plt.close(fig)

# ---- Fig 3: trajectories at k=0.5 ----
k_show = 0.5
sol = results[k_show]
xi, yi, thi, xj, yj, thj = sol.y
t = sol.t
fig, axs = plt.subplots(3, 1, figsize=(6, 6.5), sharex=True)
axs[0].plot(t, xi, label=r"$x_i$", color="tab:blue")
axs[0].plot(t, xj, label=r"$x_j$", color="tab:red", ls="--")
axs[0].plot(t, d(t), label=r"$d(t)$", color="gray", lw=1)
axs[0].set_ylabel(r"$x$"); axs[0].legend(fontsize=8, ncol=3)
axs[1].plot(t, yi, label=r"$y_i$", color="tab:blue")
axs[1].plot(t, yj, label=r"$y_j$", color="tab:red", ls="--")
axs[1].plot(t, d(t), label=r"$d(t)$", color="gray", lw=1)
axs[1].set_ylabel(r"$y$"); axs[1].legend(fontsize=8, ncol=3)
axs[2].plot(t, thi, label=r"$\theta_i$", color="tab:blue")
axs[2].plot(t, thj, label=r"$\theta_j$", color="tab:red", ls="--")
axs[2].plot(t, d(t), label=r"$d(t)$", color="gray", lw=1)
axs[2].set_ylabel(r"$\theta$"); axs[2].set_xlabel("t (s)"); axs[2].legend(fontsize=8, ncol=3)
fig.suptitle(rf"State trajectories under $k={k_show}$, sinusoidal $d(t)$")
fig.tight_layout(); fig.savefig("fig3_convergence.png", dpi=200); plt.close(fig)

# ---- Fig 4: error norm decay ----
fig, ax = plt.subplots(figsize=(6, 3.5))
tail_means = {}
for k in k_values:
    sol = results[k]
    xi, yi, thi, xj, yj, thj = sol.y
    ex, ey, eth = xi - xj, yi - yj, thi - thj
    e_norm = np.sqrt(ex**2 + ey**2 + eth**2)
    tail_means[k] = e_norm[int(0.8 * len(e_norm)):].mean()
    ax.semilogy(sol.t, e_norm, label=rf"$k={k}$", color=colors[k])
ax.set_xlabel("t (s)"); ax.set_ylabel(r"$\|e(t)\|$ (log scale)")
ax.set_title("Synchronization error norm under sinusoidal disturbance")
ax.legend(fontsize=9); ax.grid(alpha=0.3, which="both")
fig.tight_layout(); fig.savefig("fig4_error_decay.png", dpi=200); plt.close(fig)

# ---- Fig 5: delayed reception of d(t) ----
tau_i, tau_j = 0.0133, 0.0  # ~13.3 ms delay difference (underwater example)
fig, ax = plt.subplots(figsize=(6, 3.5))
delay_means = {}
for k in k_values:
    sol = solve_ivp(rhs, [0, T_final], z0, t_eval=t_eval,
                     args=(k, v_i, w_i, v_j, w_j, True, tau_i, tau_j),
                     method="RK45", rtol=1e-8, atol=1e-10)
    xi, yi, thi, xj, yj, thj = sol.y
    ex, ey, eth = xi - xj, yi - yj, thi - thj
    e_norm = np.sqrt(ex**2 + ey**2 + eth**2)
    delay_means[k] = e_norm[int(0.8 * len(e_norm)):].mean()
    ax.semilogy(sol.t, e_norm, label=rf"$k={k}$", color=colors[k])
ax.set_xlabel("t (s)"); ax.set_ylabel(r"$\|e(t)\|$ (log scale)")
ax.set_title(r"Synchronization error under delayed reception of $d(t)$")
ax.legend(fontsize=9); ax.grid(alpha=0.3, which="both")
fig.tight_layout(); fig.savefig("fig5_delay.png", dpi=200); plt.close(fig)

print("Steady-state ||e|| (no delay):")
for k in k_values:
    print(f"  k={k}: {tail_means[k]:.4f}  (bound 2*v_max/k = {2*max(v_i,v_j)/k:.4f})")
print("Steady-state ||e|| (with delay):")
for k in k_values:
    print(f"  k={k}: {delay_means[k]:.4f}")
print(f"d_max = A_d*omega_d = {d_max:.4f}")
